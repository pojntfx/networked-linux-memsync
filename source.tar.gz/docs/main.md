---
author: [Felicitas Pojtinger (Stuttgart Media University)]
date: "2023-08-04"
subject: "Efficient Synchronization of Linux Memory Regions over a Network: A Comparative Study and Implementation"
keywords:
  - TODO: Add keywords
subtitle: "TODO: Add subtitle"
lang: en-US
abstract: |
  ## \abstractname{} {.unnumbered .unlisted}

  TODO: Add abstract
bibliography: static/references.bib
csl: static/ieee.csl
---

# Efficient Synchronization of Linux Memory Regions over a Network: A Comparative Study and Implementation

## Introduction

TODO: Add introduction

## Technology

### The Linux Kernel

TODO: Add Linux kernel section
